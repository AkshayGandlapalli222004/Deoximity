import { Component } from '@angular/core';
import { Meta, MetaDefinition } from '@angular/platform-browser';
@Component({
  selector: 'app-physician-assistants',
  templateUrl: './physician-assistants.component.html',
  styleUrls: ['./physician-assistants.component.css']
})
export class PhysicianAssistantsComponent {

}
