// physician.model.ts
export interface Physician {
  id: number;
  name: string;
  summary: string;
  Education: string;
  Certifications: string;
  Awards: string;
}
