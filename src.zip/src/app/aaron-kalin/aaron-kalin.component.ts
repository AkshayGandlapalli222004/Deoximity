import { Component } from '@angular/core';

@Component({
  selector: 'app-aaron-kalin',
  templateUrl: './aaron-kalin.component.html',
  styleUrls: ['./aaron-kalin.component.css']
})
export class AaronKalinComponent {
  linksPhy: string[][] = [
    ["Home", "Contact", "Help","About Us","Press","Product","Sign in"]
  ];
}
