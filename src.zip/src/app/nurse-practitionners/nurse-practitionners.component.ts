import { Component } from '@angular/core';

@Component({
  selector: 'app-nurse-practitionners',
  templateUrl: './nurse-practitionners.component.html',
  styleUrls: ['./nurse-practitionners.component.css']
})
export class NursePractitionnersComponent {

}
