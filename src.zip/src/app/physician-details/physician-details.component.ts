import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DrListService } from '../dr-list.service';
import { Physician } from '../physician.model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Title } from '@angular/platform-browser';
import { Meta, MetaDefinition } from '@angular/platform-browser';
@Component({
  selector: 'app-physician-details',
  templateUrl: './physician-details.component.html',
  styleUrls: ['./physician-details.component.css']
})
export class PhysicianDetailsComponent  implements OnInit  {
  // title = '{{Details?.name}}';
  
  Details: any;
  physicianId: number=0;
  doctors: any[] = [];
  constructor(private titleService:Title, private http: HttpClient, private route: ActivatedRoute) {}

  ngOnInit(): void {
    // this.titleService.setTitle(this.title);
    this.route.params.subscribe(params => {
      this.physicianId = +params['id'];
      this.getDetails();
    
    });
  }

  getDetails() {
    this.http.get<any[]>('http://localhost:4200/assets/data/DrList.json').subscribe((doctors) => {
      this.doctors = doctors; // Store all physicians in the array
      this.Details = this.doctors.find(doctor => doctor.id === this.physicianId);
      console.log(this.Details);
      if (this.Details) {
        this.titleService.setTitle("Dr. "+ this.Details.name); // Set the title to the physician's name
      }
    });
  }
}