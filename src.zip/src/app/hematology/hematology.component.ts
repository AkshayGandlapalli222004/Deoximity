import { Component, OnInit } from '@angular/core';
import { Meta, MetaDefinition } from '@angular/platform-browser';
@Component({
  selector: 'app-hematology',
  templateUrl: './hematology.component.html',
  styleUrls: ['./hematology.component.css']
})
export class HematologyComponent {

}
