import { Component } from '@angular/core';

@Component({
  selector: 'app-op-med',
  templateUrl: './op-med.component.html',
  styleUrls: ['./op-med.component.css']
})
export class OpMedComponent {

}
